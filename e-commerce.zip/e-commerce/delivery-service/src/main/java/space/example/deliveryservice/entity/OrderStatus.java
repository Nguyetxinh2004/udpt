package space.example.deliveryservice.entity;

public enum OrderStatus {
    PENDING,
    SHIPPED,
    DELIVERED,
}
